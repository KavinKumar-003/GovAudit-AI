"""
data_generator.py
------------------
GovAudit-AI | Module 1: Synthetic Tender & Bid Data Generator

Generates a realistic (but 100% fictional) dataset of government tender
bids from Indian companies, with a configurable number of "hidden cartels"
seeded into the data. A cartel is a small group of shell/associated
companies that:
  - share a registration IP address (or a very close subnet),
  - share a phone-number prefix,
  - share a bank-account-number prefix,
  - and rotate bids on tenders (one member bids low & genuine, the
    others submit deliberately inflated "cover bids" close to each
    other) -- a classic bid-rigging signature.

Output files (written to ./data/):
  - companies.csv     : master list of bidding companies
  - tenders.csv        : master list of tenders
  - tender_bids.csv    : every bid submitted, one row per (tender, company)
  - ground_truth.csv   : which companies/tenders were seeded as collusive
                          (kept separate -- a real auditor would NOT have
                          this file; it exists here only so you can score
                          detector accuracy during the hackathon demo)

Run directly to generate a fresh dataset:
    python data_generator.py
"""

import os
import csv
import random
import string
from datetime import datetime, timedelta

random.seed()  # non-deterministic by default; pass a seed via generate() for repeatability

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# ---------------------------------------------------------------------------
# Synthetic name components (fictional, illustrative only)
# ---------------------------------------------------------------------------
COMPANY_PREFIXES = [
    "Bharat", "Shree", "National", "Sundar", "Vindhya", "Ganga", "Deccan",
    "Kaveri", "Himalaya", "Konkan", "Malabar", "Vidarbha", "Saraswati",
    "Krishna", "Bhoomi", "Aravalli", "Suryodaya", "Trident", "Sapthagiri",
    "Nilgiri", "Meghna", "Satpura", "Chola", "Pallava", "Rajdhani",
]
COMPANY_MIDS = [
    "Infra", "Construction", "Builders", "Engineering", "Projects",
    "Roadways", "Tech", "Systems", "Enterprises", "Industries",
    "Contractors", "Associates", "Ventures", "Works", "Logistics",
]
COMPANY_SUFFIXES = ["Pvt Ltd", "Ltd", "LLP", "& Co", "Corporation", "Group"]

DEPARTMENTS = [
    "Public Works Department (PWD)",
    "Municipal Corporation - Roads Wing",
    "State Water Resources Board",
    "Rural Development Department",
    "Urban Infrastructure Development Corp",
    "State Electricity Distribution Co.",
    "District Irrigation Division",
    "National Highways Circle",
]

TENDER_DESCRIPTIONS = [
    "Construction of 4-lane bypass road ({} km)",
    "Supply and installation of street lighting units ({} units)",
    "Rehabilitation of primary health centre buildings ({} sites)",
    "Laying of rural drinking water pipeline ({} km)",
    "Construction of overhead water storage tank ({} KL capacity)",
    "Renovation of government school blocks ({} schools)",
    "Widening and strengthening of district road ({} km)",
    "Construction of community drainage & sewerage network ({} km)",
    "Supply of transformers for rural electrification ({} units)",
    "Construction of check dams for irrigation ({} nos.)",
]

CITIES = [
    ("Chennai", "TN"), ("Coimbatore", "TN"), ("Madurai", "TN"),
    ("Hyderabad", "TS"), ("Vijayawada", "AP"), ("Bengaluru", "KA"),
    ("Mysuru", "KA"), ("Pune", "MH"), ("Nagpur", "MH"), ("Bhopal", "MP"),
    ("Jaipur", "RJ"), ("Lucknow", "UP"), ("Patna", "BR"), ("Bhubaneswar", "OD"),
]

IP_OCTET_POOLS = list(range(10, 250))


def _rand_ip():
    return f"{random.choice(IP_OCTET_POOLS)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"


def _rand_phone():
    return "9" + "".join(random.choice(string.digits) for _ in range(9))


def _rand_bank_account():
    return "".join(random.choice(string.digits) for _ in range(11))


def _rand_pan():
    letters = "".join(random.choice(string.ascii_uppercase) for _ in range(5))
    digits = "".join(random.choice(string.digits) for _ in range(4))
    return f"{letters}{digits}{random.choice(string.ascii_uppercase)}"


def _rand_gstin(state_code="33"):
    return f"{state_code}{_rand_pan()}1Z{random.choice(string.digits)}"


def _make_company_name(used_names):
    while True:
        name = f"{random.choice(COMPANY_PREFIXES)} {random.choice(COMPANY_MIDS)} {random.choice(COMPANY_SUFFIXES)}"
        if name not in used_names:
            used_names.add(name)
            return name


def generate_companies(n_companies, seed=None):
    if seed is not None:
        random.seed(seed)
    used_names = set()
    companies = []
    for i in range(1, n_companies + 1):
        city, state = random.choice(CITIES)
        companies.append({
            "company_id": f"CO{i:04d}",
            "company_name": _make_company_name(used_names),
            "city": city,
            "state": state,
            "pan": _rand_pan(),
            "gstin": _rand_gstin(),
            "contact_phone": _rand_phone(),
            "contact_email": None,  # filled after name known
            "bank_account": _rand_bank_account(),
            "registration_ip": _rand_ip(),
            "years_in_operation": random.randint(1, 25),
        })
    for c in companies:
        handle = c["company_name"].lower().replace(" ", "").replace("&", "and")[:18]
        c["contact_email"] = f"contact@{handle}{random.randint(1,99)}.co.in"
    return companies


def _seed_cartels(companies, n_cartels, cartel_size_range=(3, 5)):
    """
    Pick disjoint groups of companies and overwrite their identifying
    attributes so they share signatures (same IP subnet, same phone
    prefix, same bank prefix) -- simulating shell companies controlled
    by the same operator.
    """
    pool = companies[:]
    random.shuffle(pool)
    cartels = []
    idx = 0
    for c_num in range(n_cartels):
        size = random.randint(*cartel_size_range)
        if idx + size > len(pool):
            break
        members = pool[idx: idx + size]
        idx += size

        shared_ip_base = f"{random.choice(IP_OCTET_POOLS)}.{random.randint(0,255)}.{random.randint(0,255)}"
        shared_phone_prefix = "9" + "".join(random.choice(string.digits) for _ in range(5))
        shared_bank_prefix = "".join(random.choice(string.digits) for _ in range(6))

        for m in members:
            m["registration_ip"] = f"{shared_ip_base}.{random.randint(1,254)}"
            m["contact_phone"] = shared_phone_prefix + "".join(random.choice(string.digits) for _ in range(4))
            m["bank_account"] = shared_bank_prefix + "".join(random.choice(string.digits) for _ in range(5))

        cartels.append({
            "cartel_id": f"CARTEL{c_num+1:02d}",
            "members": [m["company_id"] for m in members],
            "shared_ip_subnet": shared_ip_base + ".x",
            "shared_phone_prefix": shared_phone_prefix,
            "shared_bank_prefix": shared_bank_prefix,
        })
    return cartels


def generate_tenders(n_tenders, seed=None):
    if seed is not None:
        random.seed(seed + 1)
    tenders = []
    start_date = datetime(2024, 4, 1)
    for i in range(1, n_tenders + 1):
        dept = random.choice(DEPARTMENTS)
        desc_template = random.choice(TENDER_DESCRIPTIONS)
        qty = random.choice([5, 8, 10, 12, 15, 20, 25, 30, 40, 50])
        desc = desc_template.format(qty)
        estimated_value = random.randint(20, 950) * 100000  # 20 lakh to 9.5 cr
        publish_date = start_date + timedelta(days=random.randint(0, 400))
        tenders.append({
            "tender_id": f"TND{i:04d}",
            "department": dept,
            "description": desc,
            "estimated_value_inr": estimated_value,
            "publish_date": publish_date.strftime("%Y-%m-%d"),
            "submission_deadline": (publish_date + timedelta(days=21)).strftime("%Y-%m-%d"),
        })
    return tenders


def _benign_bid_amount(estimated_value):
    """Natural-looking competitive bid: random variation around estimate,
    which tends to produce a roughly Benford-compliant leading-digit spread
    across many tenders."""
    factor = random.uniform(0.85, 1.15)
    amount = estimated_value * factor
    # round to a "human" figure
    amount = round(amount / 1000) * 1000
    return int(amount)


def _cartel_bid_amounts(estimated_value, n_members):
    """
    Simulate classic bid-rotation: one designated 'winner' bids low & close
    to the estimate, the rest submit cover bids clustered a fixed % above
    the winner -- unnaturally tight spread, and amounts that often share
    the same rounded/truncated digit pattern (a Benford red flag).
    """
    winner_amount = estimated_value * random.uniform(0.94, 0.99)
    winner_amount = round(winner_amount / 500) * 500
    amounts = [int(winner_amount)]
    for _ in range(n_members - 1):
        bump = random.uniform(0.02, 0.06)
        cover = winner_amount * (1 + bump)
        cover = round(cover / 500) * 500  # same rounding convention -> suspicious uniformity
        amounts.append(int(cover))
    random.shuffle(amounts)
    return amounts


def generate_bids(companies, tenders, cartels, bidders_per_tender=(5, 8), seed=None):
    if seed is not None:
        random.seed(seed + 2)

    company_by_id = {c["company_id"]: c for c in companies}
    cartel_members_flat = {cid: cart for cart in cartels for cid in cart["members"]}
    all_ids = [c["company_id"] for c in companies]

    bids = []
    tender_cartel_map = {}  # tender_id -> cartel_id if a cartel bid in it

    for t in tenders:
        n_bidders = random.randint(*bidders_per_tender)

        # Decide whether a cartel operates in this tender (~55% of tenders, if any cartels exist)
        use_cartel = cartels and random.random() < 0.55
        chosen_cartel = random.choice(cartels) if use_cartel else None

        bidder_ids = set()
        if chosen_cartel:
            bidder_ids.update(chosen_cartel["members"])
            tender_cartel_map[t["tender_id"]] = chosen_cartel["cartel_id"]

        # fill remaining slots with random honest companies (never partial-overlap with a different cartel,
        # to keep the seeded signal clean for the demo)
        remaining_pool = [cid for cid in all_ids if cid not in bidder_ids and cid not in cartel_members_flat]
        random.shuffle(remaining_pool)
        while len(bidder_ids) < n_bidders and remaining_pool:
            bidder_ids.add(remaining_pool.pop())

        bidder_ids = list(bidder_ids)

        if chosen_cartel:
            cartel_amounts = _cartel_bid_amounts(t["estimated_value_inr"], len(chosen_cartel["members"]))
            cartel_amount_map = dict(zip(chosen_cartel["members"], cartel_amounts))
        else:
            cartel_amount_map = {}

        for cid in bidder_ids:
            comp = company_by_id[cid]
            if cid in cartel_amount_map:
                amount = cartel_amount_map[cid]
            else:
                amount = _benign_bid_amount(t["estimated_value_inr"])

            bid_date = datetime.strptime(t["publish_date"], "%Y-%m-%d") + timedelta(
                days=random.randint(1, 20)
            )

            bids.append({
                "tender_id": t["tender_id"],
                "company_id": cid,
                "company_name": comp["company_name"],
                "bid_amount_inr": amount,
                "bid_date": bid_date.strftime("%Y-%m-%d"),
                "contact_phone": comp["contact_phone"],
                "contact_email": comp["contact_email"],
                "registration_ip": comp["registration_ip"],
                "bank_account": comp["bank_account"],
                "pan": comp["pan"],
                "gstin": comp["gstin"],
            })

    return bids, tender_cartel_map


def _write_csv(path, rows, fieldnames):
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def generate(n_companies=40, n_tenders=18, n_cartels=3, seed=42, out_dir=None):
    """Main entry point. Returns dict of generated dataframrelated lists and writes CSVs."""
    out_dir = out_dir or OUT_DIR
    os.makedirs(out_dir, exist_ok=True)

    random.seed(seed)
    companies = generate_companies(n_companies, seed=seed)
    cartels = _seed_cartels(companies, n_cartels)
    tenders = generate_tenders(n_tenders, seed=seed)
    bids, tender_cartel_map = generate_bids(companies, tenders, cartels, seed=seed)

    _write_csv(
        os.path.join(out_dir, "companies.csv"),
        companies,
        ["company_id", "company_name", "city", "state", "pan", "gstin",
         "contact_phone", "contact_email", "bank_account", "registration_ip",
         "years_in_operation"],
    )
    _write_csv(
        os.path.join(out_dir, "tenders.csv"),
        tenders,
        ["tender_id", "department", "description", "estimated_value_inr",
         "publish_date", "submission_deadline"],
    )
    _write_csv(
        os.path.join(out_dir, "tender_bids.csv"),
        bids,
        ["tender_id", "company_id", "company_name", "bid_amount_inr", "bid_date",
         "contact_phone", "contact_email", "registration_ip", "bank_account",
         "pan", "gstin"],
    )

    # Ground truth (kept separate — for demo scoring only)
    gt_rows = []
    for cart in cartels:
        for member in cart["members"]:
            gt_rows.append({
                "cartel_id": cart["cartel_id"],
                "company_id": member,
                "shared_ip_subnet": cart["shared_ip_subnet"],
                "shared_phone_prefix": cart["shared_phone_prefix"],
                "shared_bank_prefix": cart["shared_bank_prefix"],
            })
    _write_csv(
        os.path.join(out_dir, "ground_truth.csv"),
        gt_rows,
        ["cartel_id", "company_id", "shared_ip_subnet", "shared_phone_prefix", "shared_bank_prefix"],
    )

    print(f"[data_generator] Wrote {len(companies)} companies, {len(tenders)} tenders, "
          f"{len(bids)} bids, {len(cartels)} seeded cartels -> {out_dir}")
    return {
        "companies": companies,
        "tenders": tenders,
        "bids": bids,
        "cartels": cartels,
        "tender_cartel_map": tender_cartel_map,
    }


if __name__ == "__main__":
    generate()
