"""
app_ui.py
---------
GovAudit-AI | Module 5: Interactive Streamlit Dashboard

Ties data_generator.py, graph_engine.py, benford_engine.py and
report_generator.py together into a single-page interactive dashboard:

  - Sidebar: regenerate a fresh synthetic dataset (with adjustable size /
    number of seeded cartels) and re-run the full analysis pipeline
  - Tab 1 "Overview": headline KPIs, risk distribution
  - Tab 2 "Cartel Network": interactive graph of companies & relationship
    edges (color-coded by cluster / risk), evidence table
  - Tab 3 "Benford's Law": digit-distribution chart, exploratory watchlist
  - Tab 4 "Tender Explorer": browse raw bids per tender
  - Tab 5 "Audit Dossier": one-click PDF generation + download button

Run with:
    streamlit run app_ui.py

NOTE: This file depends on `streamlit`, `plotly`, and `streamlit-agraph`,
which are not part of the base Python standard library. Install with:
    pip install streamlit plotly streamlit-agraph pandas networkx reportlab matplotlib
"""

import os
import json
import subprocess
import sys

import pandas as pd
import streamlit as st
import plotly.graph_objects as go
import networkx as nx

import data_generator
import graph_engine
import benford_engine
import report_generator

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

st.set_page_config(
    page_title="GovAudit-AI | Bid-Rigging & Pricing Anomaly Detector",
    page_icon="🕵️",
    layout="wide",
)


# ---------------------------------------------------------------------------
# Data / pipeline helpers
# ---------------------------------------------------------------------------

def data_exists():
    return os.path.exists(os.path.join(DATA_DIR, "tender_bids.csv"))


def run_pipeline(n_companies, n_tenders, n_cartels, seed):
    with st.spinner("Generating synthetic tender & bid dataset..."):
        data_generator.generate(
            n_companies=n_companies, n_tenders=n_tenders,
            n_cartels=n_cartels, seed=seed, out_dir=DATA_DIR,
        )
    with st.spinner("Running network / cartel-detection engine..."):
        graph_engine.analyze(data_dir=DATA_DIR)
    with st.spinner("Running Benford's Law pricing analysis..."):
        benford_engine.analyze(data_dir=DATA_DIR)
    st.success("Pipeline complete.")


@st.cache_data(show_spinner=False)
def load_csv(name):
    return pd.read_csv(os.path.join(DATA_DIR, name))


def load_json(name):
    path = os.path.join(DATA_DIR, name)
    if not os.path.exists(path):
        return None
    with open(path) as f:
        return json.load(f)


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------

st.sidebar.title("🕵️ GovAudit-AI")
st.sidebar.caption("Tender bid-rigging & pricing-anomaly screening tool")
st.sidebar.markdown("---")
st.sidebar.subheader("Dataset controls")

n_companies = st.sidebar.slider("Number of companies", 15, 100, 40, step=5)
n_tenders = st.sidebar.slider("Number of tenders", 5, 60, 18, step=1)
n_cartels = st.sidebar.slider("Seeded cartels (for demo)", 0, 6, 3, step=1)
seed = st.sidebar.number_input("Random seed", value=42, step=1)

if st.sidebar.button("🔄 Generate data & run analysis", type="primary", use_container_width=True):
    run_pipeline(n_companies, n_tenders, n_cartels, seed)
    st.cache_data.clear()

st.sidebar.markdown("---")
st.sidebar.caption(
    "This demo dataset is 100% synthetic (no real companies or individuals). "
    "Cartels are deliberately seeded so the detection pipeline can be evaluated."
)

if not data_exists():
    st.title("🕵️ GovAudit-AI")
    st.info("👈 Click **Generate data & run analysis** in the sidebar to get started.")
    st.stop()


# ---------------------------------------------------------------------------
# Load data
# ---------------------------------------------------------------------------

bids_df = load_csv("tender_bids.csv")
tenders_df = load_csv("tenders.csv")
companies_df = load_csv("companies.csv")
clusters = load_json("suspected_cartels.json") or []
benford_report = load_json("benford_report.json")
graph_nodes = load_json("graph_nodes.json") or []
graph_edges = load_json("graph_edges.json") or []

st.title("🕵️ GovAudit-AI")
st.caption("AI-assisted screening for collusive bidding (cartel) patterns and pricing manipulation in public tenders")

tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "📊 Overview", "🕸️ Cartel Network", "🔢 Benford's Law", "📋 Tender Explorer", "📄 Audit Dossier",
])


# ---------------------------------------------------------------------------
# Tab 1: Overview
# ---------------------------------------------------------------------------
with tab1:
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Companies analyzed", len(companies_df))
    col2.metric("Tenders analyzed", len(tenders_df))
    col3.metric("Total bids", len(bids_df))
    n_high = sum(1 for c in clusters if c["risk_score"] >= 75)
    col4.metric("HIGH RISK clusters", n_high)

    st.markdown("### Risk distribution across suspected clusters")
    if clusters:
        risk_df = pd.DataFrame([
            {"Cluster": f"Cluster {i+1}", "Companies": c["size"], "Risk Score": c["risk_score"],
             "Classification": ("HIGH" if c["risk_score"] >= 75 else "MEDIUM" if c["risk_score"] >= 50 else "LOW")}
            for i, c in enumerate(clusters)
        ])
        fig = go.Figure(go.Bar(
            x=risk_df["Cluster"], y=risk_df["Risk Score"],
            marker_color=risk_df["Risk Score"].apply(
                lambda s: "#c0392b" if s >= 75 else ("#e67e22" if s >= 50 else "#f1c40f")
            ),
            text=risk_df["Companies"].astype(str) + " cos.",
            textposition="outside",
        ))
        fig.add_hline(y=75, line_dash="dash", line_color="grey", annotation_text="High-risk threshold")
        fig.update_layout(yaxis_range=[0, 105], yaxis_title="Risk Score (0-100)", height=420)
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(risk_df, use_container_width=True, hide_index=True)
    else:
        st.info("No suspected clusters detected in the current dataset.")

    if benford_report:
        st.markdown("### Overall pricing conformity (Benford's Law)")
        ov = benford_report["overall"]
        bcol1, bcol2, bcol3 = st.columns(3)
        bcol1.metric("Conformity", ov["conformity"])
        bcol2.metric("Mean Absolute Deviation", ov["mean_absolute_deviation"])
        bcol3.metric("Sample size (bids)", ov["sample_size"])


# ---------------------------------------------------------------------------
# Tab 2: Cartel Network Graph
# ---------------------------------------------------------------------------
with tab2:
    st.markdown("### Interactive relationship graph")
    st.caption(
        "Nodes = bidding companies. Edges = shared IP subnet, shared phone/bank prefix, "
        "and/or tight-spread repeated co-bidding. Node color reflects the risk score of the "
        "cluster it belongs to; isolated (unconnected) companies show no relationship signal."
    )

    if not graph_nodes:
        st.info("No graph data available — run the analysis pipeline first.")
    else:
        G = nx.Graph()
        for n in graph_nodes:
            G.add_node(n["id"], **n)
        for e in graph_edges:
            G.add_edge(e["source"], e["target"], **e)

        pos = nx.spring_layout(G, seed=7, k=0.6)

        cluster_score = {i: c["risk_score"] for i, c in enumerate(clusters)}

        def node_color(cluster_id):
            if cluster_id == -1 or cluster_id not in cluster_score:
                return "#95a5a6"
            score = cluster_score[cluster_id]
            return "#c0392b" if score >= 75 else ("#e67e22" if score >= 50 else "#f1c40f")

        edge_x, edge_y = [], []
        for a, b in G.edges():
            x0, y0 = pos[a]
            x1, y1 = pos[b]
            edge_x += [x0, x1, None]
            edge_y += [y0, y1, None]

        edge_trace = go.Scatter(
            x=edge_x, y=edge_y, mode="lines",
            line=dict(width=1, color="#bbbbbb"), hoverinfo="none",
        )

        node_x, node_y, node_text, node_colors, node_sizes = [], [], [], [], []
        for n, data in G.nodes(data=True):
            x, y = pos[n]
            node_x.append(x)
            node_y.append(y)
            deg = G.degree(n)
            node_text.append(f"{data.get('label', n)} ({n})<br>Connections: {deg}")
            node_colors.append(node_color(data.get("cluster", -1)))
            node_sizes.append(14 + deg * 4)

        node_trace = go.Scatter(
            x=node_x, y=node_y, mode="markers", hoverinfo="text", text=node_text,
            marker=dict(color=node_colors, size=node_sizes, line=dict(width=1, color="#333333")),
        )

        fig = go.Figure(data=[edge_trace, node_trace])
        fig.update_layout(
            showlegend=False, height=620, margin=dict(l=10, r=10, t=10, b=10),
            xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            plot_bgcolor="white",
        )
        st.plotly_chart(fig, use_container_width=True)

        st.markdown("### Suspected clusters — evidence detail")
        if not clusters:
            st.info("No clusters met the minimum evidence threshold.")
        for i, c in enumerate(clusters):
            badge = "🔴 HIGH" if c["risk_score"] >= 75 else ("🟠 MEDIUM" if c["risk_score"] >= 50 else "🟡 LOW")
            with st.expander(f"Cluster {i+1} — {badge} RISK (score {c['risk_score']}/100) — {c['size']} companies"):
                st.write("**Members:**")
                st.dataframe(
                    pd.DataFrame({"Company ID": c["members"], "Company Name": c["member_names"]}),
                    use_container_width=True, hide_index=True,
                )
                st.write("**Evidence:**")
                for e in c["evidence"]:
                    st.markdown(f"- {e}")


# ---------------------------------------------------------------------------
# Tab 3: Benford's Law
# ---------------------------------------------------------------------------
with tab3:
    if not benford_report:
        st.info("No Benford analysis available — run the analysis pipeline first.")
    else:
        ov = benford_report["overall"]
        st.markdown("### Overall first-digit distribution vs. Benford's Law")
        digits = [str(d) for d in range(1, 10)]
        fig = go.Figure()
        fig.add_trace(go.Bar(x=digits, y=[ov["observed_distribution"][d] for d in digits], name="Observed", marker_color="#c0392b"))
        fig.add_trace(go.Bar(x=digits, y=[ov["expected_distribution"][d] for d in digits], name="Benford Expected", marker_color="#2c3e50"))
        fig.update_layout(barmode="group", height=420, xaxis_title="Leading digit", yaxis_title="Proportion")
        st.plotly_chart(fig, use_container_width=True)

        c1, c2, c3 = st.columns(3)
        c1.metric("Conformity", ov["conformity"])
        c2.metric("MAD", ov["mean_absolute_deviation"])
        c3.metric("Chi-square", ov["chi_square_statistic"])

        st.markdown("### Exploratory tender watchlist")
        st.caption(
            "⚠️ These tenders have too few bids for a statistically confident Benford verdict on "
            "their own. Treat as informational — cross-reference against the Cartel Network tab."
        )
        watchlist = benford_report.get("exploratory_tender_watchlist", [])
        if watchlist:
            wl_df = pd.DataFrame([
                {"Tender ID": w["tender_id"], "MAD": w["mean_absolute_deviation"],
                 "Sample size": w["sample_size"], "Conformity": w["conformity"]}
                for w in watchlist
            ])
            st.dataframe(wl_df, use_container_width=True, hide_index=True)
        else:
            st.info("No tenders on the exploratory watchlist.")

        flagged_companies = benford_report.get("flagged_companies", [])
        st.markdown("### Companies flagged (confident, sufficient sample size)")
        if flagged_companies:
            fc_df = pd.DataFrame([
                {"Company ID": f["company_id"], "MAD": f["mean_absolute_deviation"],
                 "Sample size": f["sample_size"], "Conformity": f["conformity"]}
                for f in flagged_companies
            ])
            st.dataframe(fc_df, use_container_width=True, hide_index=True)
        else:
            st.info("No companies had a large enough bid history for a confident flag in this dataset.")


# ---------------------------------------------------------------------------
# Tab 4: Tender Explorer
# ---------------------------------------------------------------------------
with tab4:
    st.markdown("### Browse tenders and bids")
    selected_tender = st.selectbox("Select a tender", tenders_df["tender_id"].tolist())
    trow = tenders_df[tenders_df["tender_id"] == selected_tender].iloc[0]

    st.write(f"**Department:** {trow['department']}")
    st.write(f"**Description:** {trow['description']}")
    st.write(f"**Estimated value:** ₹{trow['estimated_value_inr']:,}")
    st.write(f"**Publish date:** {trow['publish_date']}  |  **Deadline:** {trow['submission_deadline']}")

    tender_bids = bids_df[bids_df["tender_id"] == selected_tender].sort_values("bid_amount_inr")
    cartel_member_ids = {m for c in clusters for m in c["members"]}
    tender_bids = tender_bids.copy()
    tender_bids["In suspected cluster?"] = tender_bids["company_id"].apply(
        lambda cid: "⚠️ Yes" if cid in cartel_member_ids else "No"
    )
    st.dataframe(
        tender_bids[["company_id", "company_name", "bid_amount_inr", "bid_date", "In suspected cluster?"]],
        use_container_width=True, hide_index=True,
    )


# ---------------------------------------------------------------------------
# Tab 5: Audit Dossier (PDF)
# ---------------------------------------------------------------------------
with tab5:
    st.markdown("### Generate formal audit dossier (PDF)")
    st.caption(
        "Compiles the cartel-network findings and Benford's Law analysis into a formatted "
        "PDF suitable for internal circulation or CVC-style preliminary audit review."
    )
    if st.button("📄 Generate PDF Audit Dossier", type="primary"):
        with st.spinner("Building PDF report..."):
            path = report_generator.build_report(data_dir=DATA_DIR)
        st.success("Dossier generated.")
        with open(path, "rb") as f:
            st.download_button(
                "⬇️ Download GovAudit_AI_Audit_Dossier.pdf",
                data=f.read(),
                file_name="GovAudit_AI_Audit_Dossier.pdf",
                mime="application/pdf",
            )

st.markdown("---")
st.caption(
    "GovAudit-AI is a screening tool, not a legal finding. All flagged relationships require "
    "independent human verification before any action is taken. Demo dataset is entirely synthetic."
)
