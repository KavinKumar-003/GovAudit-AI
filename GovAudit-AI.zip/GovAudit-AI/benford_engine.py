"""
benford_engine.py
------------------
GovAudit-AI | Module 3: Benford's Law Pricing-Manipulation Engine

Benford's Law states that in many naturally occurring collections of
numbers (unmanipulated financial figures included), the leading digit
is not uniformly distributed: '1' appears first ~30.1% of the time,
'2' ~17.6%, ... down to '9' ~4.6%. Deviation from this curve is a
well-established, widely used forensic-audit signal for fabricated or
manipulated figures (it's used by tax authorities and the CVC/CAG in
real audits as a *screening* tool, not standalone proof).

This module:
  - Computes the observed first-digit distribution of bid amounts
    (overall, and per-tender / per-company)
  - Compares it to the theoretical Benford distribution using:
      * Mean Absolute Deviation (MAD) -- Nigrini's standard thresholds
      * Chi-square goodness-of-fit statistic
  - Flags tenders/companies whose bids deviate beyond Nigrini's
    "Marginal" / "Nonconformity" thresholds

Nigrini MAD thresholds (first-digit test):
    0.000 - 0.006  : Close conformity
    0.006 - 0.012  : Acceptable conformity
    0.012 - 0.015  : Marginally acceptable conformity
    > 0.015        : Nonconformity  (flag for review)

Outputs (to ./data/):
  - benford_report.json : overall + per-tender + per-company results

Run directly (after data_generator.py) to analyze the generated dataset:
    python benford_engine.py
"""

import os
import json
import math
from collections import Counter

import pandas as pd

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

BENFORD_EXPECTED = {d: math.log10(1 + 1 / d) for d in range(1, 10)}

NIGRINI_THRESHOLDS = [
    (0.006, "Close conformity"),
    (0.012, "Acceptable conformity"),
    (0.015, "Marginally acceptable conformity"),
    (float("inf"), "Nonconformity"),
]


def first_digit(n):
    n = abs(int(n))
    while n >= 10:
        n //= 10
    return n if n > 0 else None


def observed_distribution(amounts):
    digits = [first_digit(a) for a in amounts if a and a > 0]
    digits = [d for d in digits if d is not None]
    n = len(digits)
    counts = Counter(digits)
    dist = {d: counts.get(d, 0) / n if n else 0 for d in range(1, 10)}
    return dist, n


def mean_absolute_deviation(observed, expected=BENFORD_EXPECTED):
    return sum(abs(observed[d] - expected[d]) for d in range(1, 10)) / 9


def chi_square_stat(observed_counts_dict, n, expected=BENFORD_EXPECTED):
    chi2 = 0.0
    for d in range(1, 10):
        expected_count = expected[d] * n
        observed_count = observed_counts_dict.get(d, 0) * n if isinstance(observed_counts_dict.get(d, 0), float) and observed_counts_dict.get(d,0) <=1 else observed_counts_dict.get(d, 0)
        if expected_count > 0:
            chi2 += (observed_count - expected_count) ** 2 / expected_count
    return chi2


def conformity_label(mad):
    for threshold, label in NIGRINI_THRESHOLDS:
        if mad <= threshold:
            return label
    return "Nonconformity"


def analyze_amounts(amounts, min_sample=10):
    """Returns a dict summarizing Benford conformity for a list of bid amounts.
    min_sample: Benford's law is unreliable on very small samples; below this
    we still compute stats but flag low_confidence=True."""
    dist, n = observed_distribution(amounts)
    if n == 0:
        return None
    mad = mean_absolute_deviation(dist)
    counts = Counter(first_digit(a) for a in amounts if a and a > 0)
    chi2 = chi_square_stat(counts, n)
    return {
        "sample_size": n,
        "observed_distribution": {str(k): round(v, 4) for k, v in dist.items()},
        "expected_distribution": {str(k): round(v, 4) for k, v in BENFORD_EXPECTED.items()},
        "mean_absolute_deviation": round(mad, 5),
        "chi_square_statistic": round(chi2, 3),
        "conformity": conformity_label(mad),
        "low_confidence_small_sample": n < min_sample,
    }


def analyze_dataset(bids_df):
    overall = analyze_amounts(bids_df["bid_amount_inr"].tolist())

    # NOTE on statistical power: Benford's Law is a large-sample test. A single
    # tender typically has only a handful of bidders (5-10), which is far too
    # small a sample to draw a confident conclusion from in isolation. We still
    # compute per-tender stats (useful as a *supplementary* signal alongside
    # the graph engine's cartel evidence), but require min_sample=15 before a
    # tender-level result is treated as "confident" -- realistically, almost
    # no single tender will clear that bar, and that's the honest answer.
    # Per-company analysis (aggregating a company's bids across many tenders)
    # is the more statistically defensible use of Benford here.
    per_tender = {}
    for tid, group in bids_df.groupby("tender_id"):
        result = analyze_amounts(group["bid_amount_inr"].tolist(), min_sample=15)
        if result:
            per_tender[tid] = result

    per_company = {}
    for cid, group in bids_df.groupby("company_id"):
        if len(group) < 3:
            continue  # too few bids per company to say anything meaningful
        result = analyze_amounts(group["bid_amount_inr"].tolist(), min_sample=10)
        if result:
            per_company[cid] = result

    flagged_tenders = sorted(
        [
            {"tender_id": tid, **res}
            for tid, res in per_tender.items()
            if res["conformity"] == "Nonconformity" and not res["low_confidence_small_sample"]
        ],
        key=lambda r: r["mean_absolute_deviation"],
        reverse=True,
    )

    # Exploratory watchlist: tenders with high MAD even though the sample is
    # too small to be "confident". Useful to cross-reference against the
    # graph engine's cartel clusters -- if a low-confidence Benford flag
    # lines up with a high-risk cartel cluster, that convergence of two
    # independent weak signals is itself meaningful.
    exploratory_watchlist = sorted(
        [
            {"tender_id": tid, **res}
            for tid, res in per_tender.items()
            if res["conformity"] == "Nonconformity"
        ],
        key=lambda r: r["mean_absolute_deviation"],
        reverse=True,
    )[:10]

    flagged_companies = sorted(
        [
            {"company_id": cid, **res}
            for cid, res in per_company.items()
            if res["conformity"] == "Nonconformity" and not res["low_confidence_small_sample"]
        ],
        key=lambda r: r["mean_absolute_deviation"],
        reverse=True,
    )

    return {
        "overall": overall,
        "per_tender": per_tender,
        "per_company": per_company,
        "flagged_tenders": flagged_tenders,
        "exploratory_tender_watchlist": exploratory_watchlist,
        "flagged_companies": flagged_companies,
    }


def analyze(data_dir=DATA_DIR):
    bids_path = os.path.join(data_dir, "tender_bids.csv")
    bids_df = pd.read_csv(bids_path)

    report = analyze_dataset(bids_df)

    with open(os.path.join(data_dir, "benford_report.json"), "w") as f:
        json.dump(report, f, indent=2)

    print(f"[benford_engine] Overall sample size: {report['overall']['sample_size']}")
    print(f"[benford_engine] Overall MAD: {report['overall']['mean_absolute_deviation']} "
          f"-> {report['overall']['conformity']}")
    print(f"[benford_engine] Tenders flagged as Nonconformity (confident, n>=15): {len(report['flagged_tenders'])}")
    print(f"[benford_engine] Companies flagged as Nonconformity (confident, n>=10): {len(report['flagged_companies'])}")
    print(f"[benford_engine] Exploratory watchlist (small-sample, informational only): "
          f"{len(report['exploratory_tender_watchlist'])} tenders")
    for t in report["exploratory_tender_watchlist"][:5]:
        print(f"  - {t['tender_id']} | MAD={t['mean_absolute_deviation']} | n={t['sample_size']} (low confidence)")

    return report


if __name__ == "__main__":
    analyze()
