"""
graph_engine.py
----------------
GovAudit-AI | Module 2: Collusion Network Graph Engine

Builds a NetworkX graph over bidding companies where an edge means two
companies show a *relationship signal* that is unusual for genuinely
independent competitors:

  - SHARED_IP        : same IP address, or same /24 subnet, used at
                        registration/bid submission
  - SHARED_PHONE      : same phone-number prefix (first 6 digits)
  - SHARED_BANK       : same bank-account prefix (first 6 digits)
  - CO_BID_PATTERN    : repeatedly bid on the same tenders together with
                        a suspiciously tight price spread (bid rotation)

Each edge carries a weight (number/strength of shared signals). Connected
components with 2+ signal types or 3+ members are flagged as suspected
cartels and scored by density + signal diversity.

Outputs (to ./data/):
  - graph_nodes.json / graph_edges.json  (for visualization, e.g. in the
    Streamlit app via streamlit-agraph or plotly)
  - suspected_cartels.json               (ranked list with evidence + score)

Run directly (after data_generator.py) to analyze the generated dataset:
    python graph_engine.py
"""

import os
import json
import itertools
from collections import defaultdict

import pandas as pd
import networkx as nx

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")


def _ip_subnet(ip, prefix_octets=3):
    parts = ip.split(".")
    return ".".join(parts[:prefix_octets])


def _phone_prefix(phone, n=6):
    return phone[:n]


def _bank_prefix(account, n=6):
    return account[:n]


def build_company_profile(bids_df):
    """
    Collapse the bids table down to one profile row per company (a company
    should use consistent contact details across tenders in real life; we
    take the most frequent value per field as its profile).
    """
    profiles = {}
    for cid, group in bids_df.groupby("company_id"):
        profiles[cid] = {
            "company_id": cid,
            "company_name": group["company_name"].iloc[0],
            "registration_ip": group["registration_ip"].mode().iloc[0],
            "contact_phone": group["contact_phone"].mode().iloc[0],
            "bank_account": group["bank_account"].mode().iloc[0],
            "tenders_bid": sorted(group["tender_id"].unique().tolist()),
        }
    return profiles


def find_shared_attribute_edges(profiles):
    """O(n^2) pairwise comparison over shared IP subnet / phone prefix /
    bank prefix. For hackathon-scale datasets (tens-hundreds of companies)
    this is fast; for production scale, bucket-by-attribute first."""
    edges = defaultdict(lambda: {"weight": 0, "reasons": []})

    ip_buckets = defaultdict(list)
    phone_buckets = defaultdict(list)
    bank_buckets = defaultdict(list)

    for cid, p in profiles.items():
        ip_buckets[_ip_subnet(p["registration_ip"])].append(cid)
        phone_buckets[_phone_prefix(p["contact_phone"])].append(cid)
        bank_buckets[_bank_prefix(p["bank_account"])].append(cid)

    def add_pairs(bucket_dict, reason):
        for key, members in bucket_dict.items():
            if len(members) < 2:
                continue
            for a, b in itertools.combinations(sorted(members), 2):
                edge_key = (a, b)
                edges[edge_key]["weight"] += 1
                edges[edge_key]["reasons"].append(f"{reason}: {key}.x" if reason == "SHARED_IP_SUBNET" else f"{reason}: {key}****")

    add_pairs(ip_buckets, "SHARED_IP_SUBNET")
    add_pairs(phone_buckets, "SHARED_PHONE_PREFIX")
    add_pairs(bank_buckets, "SHARED_BANK_PREFIX")

    return edges


def find_co_bid_rotation_edges(bids_df, price_spread_threshold=0.08, min_co_bids=2):
    """
    Flag pairs of companies that (a) bid together on the same tender
    repeatedly, AND (b) their bid amounts on those shared tenders sit
    within an unusually tight percentage band of each other -- classic
    cover-bidding behaviour.
    """
    edges = defaultdict(lambda: {"weight": 0, "reasons": []})

    tender_groups = bids_df.groupby("tender_id")
    pair_co_bids = defaultdict(list)  # (a,b) -> list of (amount_a, amount_b)

    for tid, group in tender_groups:
        rows = group[["company_id", "bid_amount_inr"]].values.tolist()
        for (ca, amt_a), (cb, amt_b) in itertools.combinations(rows, 2):
            key = tuple(sorted([ca, cb]))
            pair_co_bids[key].append((tid, amt_a, amt_b))

    for (a, b), co_bids in pair_co_bids.items():
        if len(co_bids) < min_co_bids:
            continue
        tight_count = 0
        for tid, amt_a, amt_b in co_bids:
            spread = abs(amt_a - amt_b) / max(amt_a, amt_b)
            if spread <= price_spread_threshold:
                tight_count += 1
        if tight_count >= min_co_bids:
            edges[(a, b)]["weight"] += tight_count
            edges[(a, b)]["reasons"].append(
                f"CO_BID_ROTATION: {tight_count} shared tenders with bid spread <= {int(price_spread_threshold*100)}%"
            )

    return edges


def merge_edges(*edge_dicts):
    merged = defaultdict(lambda: {"weight": 0, "reasons": []})
    for ed in edge_dicts:
        for key, val in ed.items():
            merged[key]["weight"] += val["weight"]
            merged[key]["reasons"].extend(val["reasons"])
    return merged


def build_graph(profiles, merged_edges):
    G = nx.Graph()
    for cid, p in profiles.items():
        G.add_node(cid, label=p["company_name"], tenders_bid=len(p["tenders_bid"]))
    for (a, b), data in merged_edges.items():
        G.add_edge(a, b, weight=data["weight"], reasons=list(set(data["reasons"])))
    return G


def score_cluster(G, nodes):
    """
    Simple, explainable risk score (0-100) combining:
      - edge density within the cluster (how interconnected)
      - diversity of evidence types (IP + phone + bank + co-bid = stronger)
      - cluster size (bigger coordinated rings are more concerning up to a point)
    """
    sub = G.subgraph(nodes)
    n = sub.number_of_nodes()
    if n < 2:
        return 0.0
    max_edges = n * (n - 1) / 2
    density = sub.number_of_edges() / max_edges if max_edges else 0

    all_reason_types = set()
    for _, _, d in sub.edges(data=True):
        for r in d.get("reasons", []):
            all_reason_types.add(r.split(":")[0])

    diversity_score = min(len(all_reason_types) / 4.0, 1.0)  # up to 4 signal types
    size_score = min(n / 6.0, 1.0)

    score = (0.45 * density + 0.40 * diversity_score + 0.15 * size_score) * 100
    return round(score, 1)


def detect_suspected_cartels(G, min_size=2):
    clusters = []
    for component in nx.connected_components(G):
        if len(component) < min_size:
            continue
        score = score_cluster(G, component)
        sub = G.subgraph(component)
        reasons = set()
        for _, _, d in sub.edges(data=True):
            reasons.update(d.get("reasons", []))
        clusters.append({
            "members": sorted(component),
            "member_names": [G.nodes[c]["label"] for c in sorted(component)],
            "size": len(component),
            "risk_score": score,
            "evidence": sorted(reasons),
        })
    clusters.sort(key=lambda c: c["risk_score"], reverse=True)
    return clusters


def export_for_visualization(G, clusters, out_dir=DATA_DIR):
    cluster_of_node = {}
    for i, c in enumerate(clusters):
        for m in c["members"]:
            cluster_of_node[m] = i

    nodes = []
    for n, data in G.nodes(data=True):
        nodes.append({
            "id": n,
            "label": data.get("label", n),
            "cluster": cluster_of_node.get(n, -1),
            "tenders_bid": data.get("tenders_bid", 0),
        })

    edges = []
    for a, b, data in G.edges(data=True):
        edges.append({
            "source": a,
            "target": b,
            "weight": data.get("weight", 1),
            "reasons": data.get("reasons", []),
        })

    with open(os.path.join(out_dir, "graph_nodes.json"), "w") as f:
        json.dump(nodes, f, indent=2)
    with open(os.path.join(out_dir, "graph_edges.json"), "w") as f:
        json.dump(edges, f, indent=2)
    with open(os.path.join(out_dir, "suspected_cartels.json"), "w") as f:
        json.dump(clusters, f, indent=2)


def analyze(data_dir=DATA_DIR):
    bids_path = os.path.join(data_dir, "tender_bids.csv")
    bids_df = pd.read_csv(bids_path, dtype={"contact_phone": str, "bank_account": str})

    profiles = build_company_profile(bids_df)
    attr_edges = find_shared_attribute_edges(profiles)
    cobid_edges = find_co_bid_rotation_edges(bids_df)
    merged = merge_edges(attr_edges, cobid_edges)

    G = build_graph(profiles, merged)
    clusters = detect_suspected_cartels(G, min_size=2)
    export_for_visualization(G, clusters, out_dir=data_dir)

    print(f"[graph_engine] Companies: {G.number_of_nodes()}, Relationship edges: {G.number_of_edges()}")
    print(f"[graph_engine] Suspected cartel clusters found: {len(clusters)}")
    for c in clusters:
        print(f"  - {c['members']} | risk_score={c['risk_score']} | evidence_types="
              f"{sorted(set(r.split(':')[0] for r in c['evidence']))}")

    return G, clusters


if __name__ == "__main__":
    analyze()
