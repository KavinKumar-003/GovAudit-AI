# GovAudit-AI

AI-assisted screening tool for detecting **collusive bidding (cartels)** and
**pricing manipulation** in government tenders — built for Smart India
Hackathon-style demos. Entirely synthetic data; no real companies or people.

## What it does

```
[ data_generator.py ]  ──> Generates realistic (synthetic) Indian company bid CSVs,
                            with a configurable number of hidden cartels seeded in
          │
          ▼
[ graph_engine.py ]    ──> Builds a NetworkX relationship graph (shared IP subnet,
                            phone/bank-account prefix, tight-spread co-bidding) and
                            scores suspected cartel clusters 0-100
          │
          ▼
[ benford_engine.py ]  ──> Runs Benford's Law first-digit analysis on bid amounts
                            (Nigrini MAD thresholds) to flag pricing anomalies,
                            with honest small-sample confidence handling
          │
          ▼
[ report_generator.py ]──> Auto-generates a formatted PDF "Audit Dossier"
                            (cover page, executive summary, methodology, cluster
                            evidence, Benford charts, recommendations, disclaimer)
          │
          ▼
[ app_ui.py ]           ──> Streamlit dashboard: interactive network graph,
                            Benford charts, tender explorer, one-click PDF download
```

## Setup

```bash
pip install -r requirements.txt
```

## Run

**Option A — full interactive dashboard:**
```bash
streamlit run app_ui.py
```
Open http://localhost:8501 — use the sidebar to generate a dataset and run
the pipeline, then explore the tabs.

**Option B — command line, step by step:**
```bash
python data_generator.py     # writes ./data/*.csv (companies, tenders, bids, ground_truth)
python graph_engine.py       # writes ./data/graph_nodes.json, graph_edges.json, suspected_cartels.json
python benford_engine.py     # writes ./data/benford_report.json
python report_generator.py   # writes ./data/GovAudit_AI_Audit_Dossier.pdf
```

## Files produced in `./data/`

| File | Description |
|---|---|
| `companies.csv` | Master list of bidding companies |
| `tenders.csv` | Master list of tenders |
| `tender_bids.csv` | Every bid submitted (one row per tender × company) |
| `ground_truth.csv` | Which companies were seeded as a cartel (demo scoring only — a real auditor wouldn't have this) |
| `graph_nodes.json` / `graph_edges.json` | Relationship graph for visualization |
| `suspected_cartels.json` | Ranked cartel clusters with evidence + risk score |
| `benford_report.json` | Full Benford's Law analysis (overall / per-tender / per-company) |
| `GovAudit_AI_Audit_Dossier.pdf` | Final formatted audit report |

## Important limitations (say this in your SIH pitch — it makes the project *stronger*, not weaker)

- This is a **screening tool**, not proof of wrongdoing. Shared infrastructure,
  tight bid spreads, and digit-distribution anomalies can have innocent
  explanations (e.g. shared CA/consultant, disclosed sister companies, or
  simple small-sample noise).
- Benford's Law is a **large-sample** test. A single tender typically has too
  few bidders (5-10) for a statistically confident verdict on its own — the
  engine reports these honestly as "exploratory / low confidence" rather than
  overstating certainty, and leans on per-company (multi-tender) aggregation
  and convergence with the graph evidence instead.
- On real data, the shared-attribute detection (IP/phone/bank prefix) would
  need to be adapted to whatever fields are actually captured by the
  e-procurement portal (e.g. GeM, state e-tender portals) — the field names
  here are illustrative.

## Extending for the real hackathon submission

- Swap `data_generator.py` for a loader of real (anonymized/sample)
  e-procurement data — the graph/Benford engines don't care about the source.
- Add a "case file" export (CSV of flagged companies) for handoff to an
  investigating officer.
- Add time-series bid analysis (price trending across repeat tenders per
  vendor) as a third detection signal alongside network + Benford.
