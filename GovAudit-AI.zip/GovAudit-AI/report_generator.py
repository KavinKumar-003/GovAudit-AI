"""
report_generator.py
--------------------
GovAudit-AI | Module 4: Audit Dossier (PDF) Generator

Combines the outputs of graph_engine.py (suspected cartel clusters) and
benford_engine.py (pricing anomaly screening) into a single formatted
PDF report, styled loosely on a CVC/CAG-style preliminary audit dossier:

  1. Cover page
  2. Executive summary (counts, top risk score, headline findings)
  3. Methodology note (what the tool does / does not prove)
  4. Suspected cartel clusters -- one section per cluster, with member
     companies, shared-identifier evidence, and a small network snippet
  5. Benford's Law pricing analysis -- overall chart + exploratory watchlist
  6. Tender-wise flagged bid tables
  7. Recommendations & disclaimer

IMPORTANT: This tool produces a *screening report* to prioritize which
tenders/companies a human auditor should examine first. It is not proof
of wrongdoing on its own -- shared infrastructure, tight bid spreads, and
digit-distribution anomalies all have innocent explanations sometimes
(e.g. shared CA/consultant, sister companies disclosed to the department,
small sample noise). The report says this explicitly so it isn't mistaken
for a finding of guilt.

Run directly (after data_generator.py, graph_engine.py, benford_engine.py):
    python report_generator.py
"""

import os
import json
from datetime import datetime

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, Image, HRFlowable
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
CHART_DIR = os.path.join(DATA_DIR, "charts")


# ---------------------------------------------------------------------------
# Chart generation (matplotlib -> PNG, embedded into the PDF)
# ---------------------------------------------------------------------------

def make_benford_chart(benford_overall, out_path):
    digits = list(range(1, 10))
    observed = [benford_overall["observed_distribution"][str(d)] for d in digits]
    expected = [benford_overall["expected_distribution"][str(d)] for d in digits]

    fig, ax = plt.subplots(figsize=(6.2, 3.4))
    width = 0.38
    x = range(len(digits))
    ax.bar([i - width / 2 for i in x], observed, width=width, label="Observed", color="#c0392b")
    ax.bar([i + width / 2 for i in x], expected, width=width, label="Benford Expected", color="#2c3e50")
    ax.set_xticks(list(x))
    ax.set_xticklabels(digits)
    ax.set_xlabel("Leading digit of bid amount")
    ax.set_ylabel("Proportion")
    ax.set_title("Overall Bid Amount First-Digit Distribution vs. Benford's Law")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=160)
    plt.close(fig)


def make_risk_score_chart(clusters, out_path):
    if not clusters:
        return None
    labels = [f"Cluster {i+1}\n({c['size']} cos.)" for i, c in enumerate(clusters)]
    scores = [c["risk_score"] for c in clusters]
    colors_list = ["#c0392b" if s >= 75 else ("#e67e22" if s >= 50 else "#f1c40f") for s in scores]

    fig, ax = plt.subplots(figsize=(6.2, 3.2))
    ax.bar(labels, scores, color=colors_list)
    ax.set_ylabel("Risk Score (0-100)")
    ax.set_title("Suspected Cartel Clusters -- Risk Score")
    ax.set_ylim(0, 105)
    ax.axhline(75, color="grey", linestyle="--", linewidth=0.8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=160)
    plt.close(fig)
    return out_path


# ---------------------------------------------------------------------------
# PDF assembly
# ---------------------------------------------------------------------------

def _styles():
    ss = getSampleStyleSheet()
    ss.add(ParagraphStyle(name="DossierTitle", fontSize=22, leading=28, alignment=TA_CENTER,
                           textColor=colors.HexColor("#1a2530"), spaceAfter=6, fontName="Helvetica-Bold"))
    ss.add(ParagraphStyle(name="DossierSubtitle", fontSize=12, leading=16, alignment=TA_CENTER,
                           textColor=colors.HexColor("#555555"), spaceAfter=4))
    ss.add(ParagraphStyle(name="SectionHeading", fontSize=14, leading=18, spaceBefore=14, spaceAfter=8,
                           textColor=colors.HexColor("#1a2530"), fontName="Helvetica-Bold"))
    ss.add(ParagraphStyle(name="SubHeading", fontSize=11.5, leading=15, spaceBefore=10, spaceAfter=4,
                           textColor=colors.HexColor("#c0392b"), fontName="Helvetica-Bold"))
    ss.add(ParagraphStyle(name="Body", fontSize=9.7, leading=14, alignment=TA_LEFT))
    ss.add(ParagraphStyle(name="Small", fontSize=8.3, leading=11, textColor=colors.HexColor("#666666")))
    return ss


def _risk_badge_text(score):
    if score >= 75:
        return "HIGH RISK"
    elif score >= 50:
        return "MEDIUM RISK"
    else:
        return "LOW / EXPLORATORY"


def build_report(data_dir=DATA_DIR, out_path=None, generated_by="GovAudit-AI (Automated Screening Tool)"):
    os.makedirs(CHART_DIR, exist_ok=True)
    out_path = out_path or os.path.join(data_dir, "GovAudit_AI_Audit_Dossier.pdf")

    with open(os.path.join(data_dir, "suspected_cartels.json")) as f:
        clusters = json.load(f)
    with open(os.path.join(data_dir, "benford_report.json")) as f:
        benford = json.load(f)

    tenders_path = os.path.join(data_dir, "tenders.csv")
    tender_lookup = {}
    if os.path.exists(tenders_path):
        import csv as _csv
        with open(tenders_path) as f:
            for row in _csv.DictReader(f):
                tender_lookup[row["tender_id"]] = row

    benford_chart_path = os.path.join(CHART_DIR, "benford_overall.png")
    make_benford_chart(benford["overall"], benford_chart_path)

    risk_chart_path = os.path.join(CHART_DIR, "risk_scores.png")
    make_risk_score_chart(clusters, risk_chart_path)

    styles = _styles()
    doc = SimpleDocTemplate(
        out_path, pagesize=A4,
        topMargin=1.6 * cm, bottomMargin=1.6 * cm,
        leftMargin=1.8 * cm, rightMargin=1.8 * cm,
        title="GovAudit-AI Preliminary Audit Dossier",
    )
    story = []

    # ---------------- Cover Page ----------------
    story.append(Spacer(1, 3 * cm))
    story.append(Paragraph("PRELIMINARY AUDIT SCREENING DOSSIER", styles["DossierTitle"]))
    story.append(Paragraph("Government Tender Bid-Rigging &amp; Pricing Anomaly Screening", styles["DossierSubtitle"]))
    story.append(Spacer(1, 0.6 * cm))
    story.append(HRFlowable(width="60%", thickness=1, color=colors.HexColor("#c0392b"), hAlign="CENTER"))
    story.append(Spacer(1, 1.2 * cm))

    meta_table_data = [
        ["Generated by:", generated_by],
        ["Generated on:", datetime.now().strftime("%d %B %Y, %H:%M IST")],
        ["Companies analyzed:", str(len({m for c in clusters for m in c["members"]}) or "-")],
        ["Suspected cartel clusters:", str(len(clusters))],
        ["Overall Benford conformity:", benford["overall"]["conformity"]],
        ["Classification:", "FOR OFFICIAL / INTERNAL AUDIT USE ONLY"],
    ]
    meta_table = Table(meta_table_data, colWidths=[5.5 * cm, 9 * cm])
    meta_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9.5),
        ("TEXTCOLOR", (0, 0), (0, -1), colors.HexColor("#1a2530")),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LINEBELOW", (0, 0), (-1, -2), 0.4, colors.HexColor("#dddddd")),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 2.5 * cm))
    story.append(Paragraph(
        "This report was generated by an automated statistical and network-analysis screening "
        "tool. It highlights patterns that warrant human audit attention. It does <b>not</b> "
        "constitute a finding of fraud, collusion, or wrongdoing by any listed entity, and must be "
        "read together with the disclaimer in the final section before any action is taken.",
        styles["Small"],
    ))
    story.append(PageBreak())

    # ---------------- Executive Summary ----------------
    story.append(Paragraph("1. Executive Summary", styles["SectionHeading"]))
    n_high = sum(1 for c in clusters if c["risk_score"] >= 75)
    n_med = sum(1 for c in clusters if 50 <= c["risk_score"] < 75)
    n_low = sum(1 for c in clusters if c["risk_score"] < 50)
    summary_text = (
        f"The screening engine analyzed the submitted tender bid dataset and identified "
        f"<b>{len(clusters)} cluster(s)</b> of companies exhibiting one or more relationship "
        f"signals inconsistent with independent competitive bidding (shared registration IP "
        f"subnet, shared phone/bank-account prefixes, and/or tight-spread co-bidding across "
        f"multiple tenders). Of these, <b>{n_high} are classified HIGH RISK</b>, "
        f"<b>{n_med} MEDIUM RISK</b>, and <b>{n_low} LOW / EXPLORATORY</b>. "
        f"Separately, a Benford's Law analysis of overall bid-amount digit distribution returned "
        f"a conformity classification of <b>{benford['overall']['conformity']}</b> "
        f"(Mean Absolute Deviation = {benford['overall']['mean_absolute_deviation']})."
    )
    story.append(Paragraph(summary_text, styles["Body"]))
    story.append(Spacer(1, 0.3 * cm))

    if os.path.exists(risk_chart_path):
        story.append(Image(risk_chart_path, width=15.5 * cm, height=8 * cm))

    story.append(PageBreak())

    # ---------------- Methodology ----------------
    story.append(Paragraph("2. Methodology", styles["SectionHeading"]))
    method_text = """
    <b>Network Analysis (Graph Engine):</b> Bidder profiles are compared pairwise for shared
    registration IP subnet, shared phone-number prefix, shared bank-account prefix, and repeated
    co-bidding on the same tenders with an unusually tight price spread (a signature of
    "cover bidding" in bid-rotation schemes). Companies connected by two or more independent
    signal types, or forming a densely connected group, are scored higher.<br/><br/>
    <b>Benford's Law Analysis:</b> The leading digit of bid amounts is compared to the
    theoretical Benford distribution using Nigrini's Mean Absolute Deviation (MAD) thresholds.
    This is a well-established forensic-accounting screening technique, but it is a
    large-sample test -- results based on very few bids (e.g. a single tender with under ~15
    bidders) are reported separately as "exploratory / low confidence" rather than being
    treated as a confident finding.<br/><br/>
    <b>Composite risk scoring</b> combines cluster edge density, diversity of independent
    evidence types, and cluster size into a single 0-100 score used purely to prioritize
    manual review order -- it is not a probability of guilt.
    """
    story.append(Paragraph(method_text, styles["Body"]))
    story.append(PageBreak())

    # ---------------- Cartel Clusters ----------------
    story.append(Paragraph("3. Suspected Cartel Clusters", styles["SectionHeading"]))
    if not clusters:
        story.append(Paragraph("No clusters met the minimum evidence threshold.", styles["Body"]))
    for i, c in enumerate(clusters, start=1):
        badge = _risk_badge_text(c["risk_score"])
        story.append(Paragraph(f"Cluster {i} &mdash; {badge} (Score: {c['risk_score']}/100)", styles["SubHeading"]))

        members_rows = [["Company ID", "Company Name"]]
        for mid, mname in zip(c["members"], c["member_names"]):
            members_rows.append([mid, mname])
        mtable = Table(members_rows, colWidths=[3.5 * cm, 11 * cm])
        mtable.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a2530")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 8.6),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#dddddd")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f7f7f7")]),
        ]))
        story.append(mtable)
        story.append(Spacer(1, 0.15 * cm))

        evidence_text = "<br/>".join(f"&bull; {e}" for e in c["evidence"])
        story.append(Paragraph(f"<b>Evidence:</b><br/>{evidence_text}", styles["Body"]))
        story.append(Spacer(1, 0.4 * cm))

    story.append(PageBreak())

    # ---------------- Benford's Law Section ----------------
    story.append(Paragraph("4. Pricing Anomaly Analysis (Benford's Law)", styles["SectionHeading"]))
    if os.path.exists(benford_chart_path):
        story.append(Image(benford_chart_path, width=15 * cm, height=8.2 * cm))
    story.append(Spacer(1, 0.3 * cm))

    watchlist = benford.get("exploratory_tender_watchlist", [])
    if watchlist:
        story.append(Paragraph(
            "<b>Exploratory tender watchlist</b> (small sample sizes -- informational only, "
            "cross-reference with cluster evidence above before prioritizing):", styles["Body"]
        ))
        wl_rows = [["Tender ID", "Department", "MAD", "Sample Size (bids)"]]
        for w in watchlist:
            dept = tender_lookup.get(w["tender_id"], {}).get("department", "-")
            wl_rows.append([w["tender_id"], dept, str(w["mean_absolute_deviation"]), str(w["sample_size"])])
        wl_table = Table(wl_rows, colWidths=[2.5 * cm, 8.5 * cm, 2 * cm, 2.5 * cm])
        wl_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a2530")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#dddddd")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f7f7f7")]),
        ]))
        story.append(wl_table)
    else:
        story.append(Paragraph("No tenders met even the exploratory watchlist threshold.", styles["Body"]))

    story.append(PageBreak())

    # ---------------- Recommendations & Disclaimer ----------------
    story.append(Paragraph("5. Recommendations", styles["SectionHeading"]))
    story.append(Paragraph(
        "It is recommended that: (a) HIGH RISK clusters be prioritized for manual document "
        "verification -- registration filings, KYC/beneficial-ownership records, and site "
        "visits; (b) bid documents for tenders in the exploratory watchlist be cross-checked "
        "against cluster membership; (c) findings be corroborated with independent evidence "
        "before any regulatory or contractual action is taken.",
        styles["Body"],
    ))
    story.append(Spacer(1, 0.4 * cm))
    story.append(Paragraph("6. Disclaimer", styles["SectionHeading"]))
    story.append(Paragraph(
        "This dossier is generated by an automated statistical screening tool (GovAudit-AI) for "
        "prioritization purposes only. Shared infrastructure or contact details between "
        "companies, tight bid-price spreads, and digit-distribution anomalies can each have "
        "legitimate explanations. No content in this report should be treated as a legal "
        "finding, and no company or individual named herein should be presumed to have engaged "
        "in wrongdoing without independent verification by a competent audit or investigating "
        "authority.",
        styles["Small"],
    ))

    doc.build(story)
    return out_path


if __name__ == "__main__":
    path = build_report()
    print(f"[report_generator] Wrote dossier -> {path}")
